from mira_sdk import MiraClient
client = MiraClient(config={"API_KEY": "sb-782f03d4e3be67f93857cba3af9fb129"})

